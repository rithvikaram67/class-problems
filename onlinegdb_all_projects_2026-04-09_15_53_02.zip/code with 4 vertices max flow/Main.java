public class Main {
    static int V = 4;
    static boolean bfs(int[][] r, int s, int t, int[] parent) {
        boolean[] visited = new boolean[V];
        int[] q = new int[V];
        int front = 0, rear = 0;
        q[rear++] = s;
        visited[s] = true;
        parent[s] = -1;
        while (front < rear) {
            int u = q[front++];

 for (int v = 0; v < V; v++) {
                if (!visited[v] && r[u][v] > 0) {
                    q[rear++] = v;
                    parent[v] = u;
                    visited[v] = true;
                }
            }
        }
        return visited[t];
    }
 static int maxFlow(int[][] graph, int s, int t) {
        int[][] r = new int[V][V];

        for (int i = 0; i < V; i++)
            for (int j = 0; j < V; j++)
                r[i][j] = graph[i][j];

        int[] parent = new int[V];
        int max = 0;

        while (bfs(r, s, t, parent)) {

            int flow = 999;

            for (int v = t; v != s; v = parent[v])

 flow = Math.min(flow, r[parent[v]][v]);

            for (int v = t; v != s; v = parent[v]) {
                r[parent[v]][v] -= flow;
                r[v][parent[v]] += flow;
            }

            max += flow;
        }

        return max;
    }
 public static void main(String[] args) {

        int[][] graph = {
                {0, 8, 5, 0},
                {0, 0, 0, 4},
                {0, 0, 0, 3},
                {0, 0, 0, 0}
        };

        System.out.println("Maximum Flow = " + maxFlow(graph, 0, 3));
    }
}