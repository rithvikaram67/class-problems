import java.util.Scanner;

public class Main {

    public static int catchSignChange(int[] arr) {
        int count = 0;
        Integer prevSign = null; // to store previous non-zero sign

        for (int num : arr) {
            if (num == 0) {
                continue; // ignore zeros
            }

            int currSign = (num > 0) ? 1 : -1;

            if (prevSign != null && currSign != prevSign) {
                count++;
            }

            prevSign = currSign;
        }

        return count;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Input size
        System.out.print("Enter number of elements: ");
        int n = sc.nextInt();

        int[] arr = new int[n];

        // Input array elements
        System.out.println("Enter the elements:");
        for (int i = 0; i < n; i++) {
            arr[i] = sc.nextInt();
        }

        // Output
        int result = catchSignChange(arr);
        System.out.println("Sign change count = " + result);

        sc.close();
    }
}