import java.util.Scanner;
public class Main
{
	public static void main(String[] args)
	{ 
	    Scanner sc=new Scanner(System.in);
	    String word=sc.nextLine();
	    char ch=sc.next().charAt(0);
	    int first=word.indexOf(ch);
	    int second=word.indexOf(ch,first+1);
	    System.out.println(second);
	}
}
