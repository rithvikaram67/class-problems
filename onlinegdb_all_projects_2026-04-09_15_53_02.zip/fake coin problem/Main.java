import java.util.*;
public class Main
{
	public static void main(String[] args) {
	    Scanner sc=new Scanner(System.in);
	    int n=sc.nextInt();
	    int [] coins=new int[n];
	     for(int i=0;i<n;i++)
	     {
	         coins[i]=sc.nextInt();
	     }
	    int minIndex=0;
	    for(int i=1;i<n;i++)
	    if(coins[i]<coins[minIndex])
	    {
	        minIndex=i;
	    }
		System.out.println(minIndex);
	}
}
