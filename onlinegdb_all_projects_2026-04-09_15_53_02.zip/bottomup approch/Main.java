class Main{
    public static void main(String []args){
        int n=5;
        int[] dp = new int[n+1];
        dp[0]=0;
        for(int i=1;i<=n;i++){
            dp[i] = dp[i-1] + i;
        }
        System.out.println(dp[n]);
    }
    
}